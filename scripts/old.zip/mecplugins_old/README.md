# mecplugins

What is mecplugins?

Mecplugins extend wikidPad with functions that improve the journaling functionality or notebook
keeping as well as some functions specific for molecular biology.

What is WikidPad?

WikidPad is a personal information manager or personal wiki software. This software is very good
at organizing information that is no inherently well defined or easy to categorize. 
It can be understood as a collection of text file notebook pages in where cross linking of pages is very easy.

Mecplugins can be automatically installed if wikidPad was installed as a conda or setuptools (pip) package.


