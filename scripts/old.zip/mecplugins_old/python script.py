#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Installeras med pip

Kolla om wp installerat
kopiera filer till WikidPad/user_extensions
                   WikidPad/icons



"""


if __name__ is "__main__":
    pass


